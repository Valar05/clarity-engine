<template>
  <header class="w-full bg-black text-white py-12 flex flex-col items-center justify-center space-y-4">
    <div class="h-10 w-auto">
      <img src="@/assets/logo_vector.svg" alt="Logo"  />
    </div>
    <h1 class="text-xl md:text-2xl font-light text-center px-4">
      Code is my second language. <br class="hidden sm:block" />
      <span class="text-red-500">Clarity is my first.</span>
    </h1>
  </header>
</template>

<script setup>
</script>

<style scoped>
h1 {
  animation: fadeIn 1s ease-in-out;
}
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(-10px); }
  to   { opacity: 1; transform: translateY(0); }
}
</style>
