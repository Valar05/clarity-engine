<template>
  <div class="dark bg-gray-900 min-h-screen text-white font-sans border-8 border-pink-500">
    <HeaderSection />
    <!-- <ChatDock /> -->
  </div>
</template>

<script setup>
import HeaderSection from './components/HeaderSection.vue'
</script>
